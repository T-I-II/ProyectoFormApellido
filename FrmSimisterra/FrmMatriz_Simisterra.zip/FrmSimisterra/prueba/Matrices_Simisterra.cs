﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prueba
{
    public partial class Matrices_Simisterra : Form
    {
        TextBox[] matriz1 = new TextBox[50];
        TextBox[] matriz2 = new TextBox[50];
        TextBox[] OpResultado = new TextBox[50];


        public Matrices_Simisterra()
        {
            InitializeComponent();
        }

        private void btnMatriz1_Click(object sender, EventArgs e)
        {
            //creacion de controle en tiempo de ejecucion 
            TextBox[] matriz1 = new TextBox[50];
            int[] m1 = new int[40];

            int x = 20, y = 200;
            int filas = int.Parse(this.txtFilas1.Text);
            int cols = int.Parse(this.txtCols1.Text);
            

            for (int i = 0; i < (filas * cols); i++)
            {
               
                matriz1[i] = new TextBox();
                matriz1[i].Text = " ";
                matriz1[i].Width = 30; //ancho del control
                matriz1[i].Location = new Point(x, y); //posicion del control
                this.Controls.Add(matriz1[0]); //mostrar el control
                x += 42;
                if ((i + 1) % cols == 0)
                {
                    y += 30;
                    x = 20;
                }
               
            }
        }

        private void btnMatriz2_Click(object sender, EventArgs e)
        {
            //creacion de controle en tiempo de ejecucion 
            TextBox[] matriz2 = new TextBox[50];
            int[] m1 = new int[40];

            int x = 70, y = 200;
            int filas = int.Parse(this.txtFilas2.Text);
            int cols = int.Parse(this.txtCols2.Text);
            for (int i = 0; i < (filas * cols); i++)
            {
                matriz2[i] = new TextBox();
                matriz2[i].Text = "0";
                matriz2[i].Width = 40; //ancho del control
                matriz2[i].Location = new Point(x, y); //posicion del control
                this.Controls.Add(matriz2[0]); //mostrar el control
                x += 75;
                if ((i + 1) % cols == 0)
                {
                    y += 30;
                    x = 70;
                }
            }
        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            int[][] m1 = new int[3][];
            m1[0] = new int[3];
            m1[1] = new int[3];
            m1[2] = new int[3];
            int[][] m2 = new int[3][];
            m2[0] = new int[3];
            m2[1] = new int[3];
            m2[2] = new int[3];

            //pasa los elementos de la matriz1 a las matriz de enteros m1
            int cols = int.Parse(this.txtCols1.Text);
            int cols2 = int.Parse(this.txtCols2.Text);
            int i = 0, j = 0;
            for (int k = 0; k < 9; k++)
            {
                m1[i][j] = int.Parse(matriz1[k].Text);
                j++;
                if ((k + 1) % cols == 0)
                {
                    i++;
                    j = 0;
                }
            }
            //imprime la matriz m1
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 3; j++)
                {
                    Console.WriteLine($"{m1[i][j]}");
                }
                Console.WriteLine();
            }
            int m = 0;
            int n = 0;
            for (int l = 0; l < 9; l++)
            {
                m2[m][n] = int.Parse(matriz2[l].Text);
                n++;
                if ((l + 1) % cols2 == 0)
                {
                    m++;
                    n = 0;
                }
            }
            for (m = 0; m< 3; m++)
            {
                for (n = 0; n < 3; n++)
                {
                    Console.Write($"{m2[0][0]}");
                }
                Console.WriteLine();
            }
            int x = 0;
            int y = 0;
            int z = 0;

            ResulMatrices ma1;
            Resulatrices ma2;
            ResulMatrices resul;

            for (int i = 0; i < x; i++)
            {
                for (j = 0; j < z; j++)
                {
                    resul[j, i].Value = 0;
                    for (int k = 0; k < y; k++)
                    {
                        resul[j, i].Value = Convert.ToInt32(resul[j, i].Value) + Convert.ToInt32(ma1[k, i].Value) * Convert.ToInt32(ma2[j, k].Value);
                    }
                }
            }

        }
    }
}
