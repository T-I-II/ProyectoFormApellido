﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prueba
{
    public partial class Matriz_dgv_Simisterra : Form
    {
        public Matriz_dgv_Simisterra()
        {
            InitializeComponent();
        }
        // Variables publicas
        int columna0 = 0;
        int fila0 = 0;

        #region iniciaizacion
        private int[,] Grid2Mat(DataGridView X)
        {
            int nf = X.RowCount;
            int nc = X.ColumnCount;
            int[,] Resultado = new int[nf, nc];
            for (int i = 0; i < nf; i++)
            {
                for (int j = 0; j < nc; j++)
                {
                    Resultado[i, j] = int.Parse(X.Rows[i].Cells[j].Value.ToString());
                }
            }
            return Resultado;
        }
        private void Mat2grid(int[,] B, DataGridView D)
        {
            int nf = B.GetLength(0);
            int nc = B.GetLength(1);

            D.RowCount = nf;
            D.ColumnCount = nc;

            for (int i = 0; i < nf; i++)
            {
                for (int j = 0; j < nc; j++)
                {
                    D.Rows[i].Cells[j].Value = B[i, j].ToString();
                }
            }
        }
        #endregion inicializacion
        #region crear matriz
        private void btnMatriz1_Click(object sender, EventArgs e)
        {
            if (txtFilas1.Text == "" & txtCols1.Text == "")
            {
                MessageBox.Show("Hay campos vacios *RELLENA TODODS LOS CAMPOS*");
                txtFilas1.Focus();
            }
            if (txtFilas1.Text != "" & txtCols1.Text != "")
            {
                int Filas = Convert.ToInt32(txtFilas1.Text);
                int Cols = Convert.ToInt32(txtCols1.Text);

                dgvMatriz1.RowCount = Filas;
                dgvMatriz1.ColumnCount = Cols;
                txtCols1.Text = "";
                txtFilas1.Text = "";
            }
        }

        private void btnMatriz2_Click(object sender, EventArgs e)
        {
            if (txtFilas2.Text == "" & txtCols2.Text == "")
            {
                MessageBox.Show("Hay campos vacios *RELLENA TODODS LOS CAMPOS*");
                txtFilas2.Focus();
            }
            if (txtFilas2.Text != "" & txtCols2.Text != "")
            {
                int Filas2 = Convert.ToInt32(txtFilas2.Text);
                int Cols2 = Convert.ToInt32(txtCols2.Text);

                dgvMatriz2.RowCount = Filas2;
                dgvMatriz2.ColumnCount = Cols2;
                txtCols2.Text = "";
                txtFilas2.Text = "";
            }
        }
        #endregion crear matiz
        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            int[,] Mat = Grid2Mat(dgvMatriz1);
            int[,] Mat2 = Grid2Mat(dgvMatriz2);
            int FIL1 = Mat.GetLength(0);
            int COL1 = Mat.GetLength(1);
            int FILA2 = Mat2.GetLength(0);
            int COL2 = Mat2.GetLength(1);

            if (FIL1 > FILA2)
            {
                columna0 = FIL1;
            }
            else
            {
                columna0 = FILA2;
            }
            if (COL1 > COL2)
            {
                fila0 = COL1;
            }
            else
            {
                fila0 = COL2;
            }
            if (COL2 == FILA2)
            {
                int suma, resultado = 0;
                int[,] A = new int[columna0, fila0];
                for (int k = 0; k < columna0; k++)
                {
                    for (int j = 0; j < COL2; j++)
                    {
                        suma = 0;
                        for (int i = 0; i < COL1; i++)
                        {
                            resultado = resultado + (Mat[k, i] * Mat2[i, j]);
                            suma = suma + resultado;
                        }
                        A[k, j] = suma;

                        Mat2grid(A, dgvMultiplicar);
                    }
                }
            }
            else
            {
                MessageBox.Show("Matriz invalida");
            }

        }
        ////*******
    }
}
