﻿namespace prueba
{
    partial class Matriz_dgv_Simisterra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvMultiplicar = new System.Windows.Forms.DataGridView();
            this.dgvMatriz2 = new System.Windows.Forms.DataGridView();
            this.dgvMatriz1 = new System.Windows.Forms.DataGridView();
            this.btnMultiplicar = new System.Windows.Forms.Button();
            this.Cols2 = new System.Windows.Forms.Label();
            this.Filas2 = new System.Windows.Forms.Label();
            this.Cols1 = new System.Windows.Forms.Label();
            this.Filas1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtCols1 = new System.Windows.Forms.TextBox();
            this.txtFilas1 = new System.Windows.Forms.TextBox();
            this.btnMatriz1 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtCols2 = new System.Windows.Forms.TextBox();
            this.txtFilas2 = new System.Windows.Forms.TextBox();
            this.btnMatriz2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMultiplicar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMatriz2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMatriz1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvMultiplicar
            // 
            this.dgvMultiplicar.AllowUserToAddRows = false;
            this.dgvMultiplicar.AllowUserToDeleteRows = false;
            this.dgvMultiplicar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMultiplicar.Location = new System.Drawing.Point(269, 339);
            this.dgvMultiplicar.Name = "dgvMultiplicar";
            this.dgvMultiplicar.RowHeadersWidth = 51;
            this.dgvMultiplicar.RowTemplate.Height = 24;
            this.dgvMultiplicar.Size = new System.Drawing.Size(240, 150);
            this.dgvMultiplicar.TabIndex = 31;
            // 
            // dgvMatriz2
            // 
            this.dgvMatriz2.AllowUserToAddRows = false;
            this.dgvMatriz2.AllowUserToDeleteRows = false;
            this.dgvMatriz2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMatriz2.Location = new System.Drawing.Point(469, 134);
            this.dgvMatriz2.Name = "dgvMatriz2";
            this.dgvMatriz2.RowHeadersWidth = 51;
            this.dgvMatriz2.RowTemplate.Height = 24;
            this.dgvMatriz2.Size = new System.Drawing.Size(240, 150);
            this.dgvMatriz2.TabIndex = 30;
            // 
            // dgvMatriz1
            // 
            this.dgvMatriz1.AllowUserToAddRows = false;
            this.dgvMatriz1.AllowUserToDeleteRows = false;
            this.dgvMatriz1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMatriz1.Location = new System.Drawing.Point(91, 134);
            this.dgvMatriz1.Name = "dgvMatriz1";
            this.dgvMatriz1.RowHeadersWidth = 51;
            this.dgvMatriz1.RowTemplate.Height = 24;
            this.dgvMatriz1.Size = new System.Drawing.Size(240, 150);
            this.dgvMatriz1.TabIndex = 29;
            // 
            // btnMultiplicar
            // 
            this.btnMultiplicar.Location = new System.Drawing.Point(305, 290);
            this.btnMultiplicar.Name = "btnMultiplicar";
            this.btnMultiplicar.Size = new System.Drawing.Size(179, 43);
            this.btnMultiplicar.TabIndex = 28;
            this.btnMultiplicar.Text = "Multiplicar Matrices";
            this.btnMultiplicar.UseVisualStyleBackColor = true;
            this.btnMultiplicar.Click += new System.EventHandler(this.btnMultiplicar_Click);
            // 
            // Cols2
            // 
            this.Cols2.AutoSize = true;
            this.Cols2.Location = new System.Drawing.Point(498, 36);
            this.Cols2.Name = "Cols2";
            this.Cols2.Size = new System.Drawing.Size(67, 16);
            this.Cols2.TabIndex = 25;
            this.Cols2.Text = "Columnas";
            // 
            // Filas2
            // 
            this.Filas2.AutoSize = true;
            this.Filas2.Location = new System.Drawing.Point(498, -8);
            this.Filas2.Name = "Filas2";
            this.Filas2.Size = new System.Drawing.Size(36, 16);
            this.Filas2.TabIndex = 24;
            this.Filas2.Text = "Filas";
            // 
            // Cols1
            // 
            this.Cols1.AutoSize = true;
            this.Cols1.Location = new System.Drawing.Point(119, 45);
            this.Cols1.Name = "Cols1";
            this.Cols1.Size = new System.Drawing.Size(67, 16);
            this.Cols1.TabIndex = 23;
            this.Cols1.Text = "Columnas";
            // 
            // Filas1
            // 
            this.Filas1.AutoSize = true;
            this.Filas1.Location = new System.Drawing.Point(119, 1);
            this.Filas1.Name = "Filas1";
            this.Filas1.Size = new System.Drawing.Size(36, 16);
            this.Filas1.TabIndex = 22;
            this.Filas1.Text = "Filas";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtCols1);
            this.groupBox1.Controls.Add(this.txtFilas1);
            this.groupBox1.Controls.Add(this.btnMatriz1);
            this.groupBox1.Location = new System.Drawing.Point(105, -39);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(226, 167);
            this.groupBox1.TabIndex = 26;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Matriz #1";
            // 
            // txtCols1
            // 
            this.txtCols1.Location = new System.Drawing.Point(83, 81);
            this.txtCols1.Name = "txtCols1";
            this.txtCols1.Size = new System.Drawing.Size(100, 22);
            this.txtCols1.TabIndex = 5;
            // 
            // txtFilas1
            // 
            this.txtFilas1.Location = new System.Drawing.Point(83, 37);
            this.txtFilas1.Name = "txtFilas1";
            this.txtFilas1.Size = new System.Drawing.Size(100, 22);
            this.txtFilas1.TabIndex = 4;
            // 
            // btnMatriz1
            // 
            this.btnMatriz1.Location = new System.Drawing.Point(52, 115);
            this.btnMatriz1.Name = "btnMatriz1";
            this.btnMatriz1.Size = new System.Drawing.Size(131, 41);
            this.btnMatriz1.TabIndex = 0;
            this.btnMatriz1.Text = "Crear matriz #1";
            this.btnMatriz1.UseVisualStyleBackColor = true;
            this.btnMatriz1.Click += new System.EventHandler(this.btnMatriz1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtCols2);
            this.groupBox2.Controls.Add(this.txtFilas2);
            this.groupBox2.Controls.Add(this.btnMatriz2);
            this.groupBox2.Location = new System.Drawing.Point(470, -39);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(239, 167);
            this.groupBox2.TabIndex = 27;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Matriz #2";
            // 
            // txtCols2
            // 
            this.txtCols2.Location = new System.Drawing.Point(99, 72);
            this.txtCols2.Name = "txtCols2";
            this.txtCols2.Size = new System.Drawing.Size(100, 22);
            this.txtCols2.TabIndex = 3;
            // 
            // txtFilas2
            // 
            this.txtFilas2.Location = new System.Drawing.Point(99, 28);
            this.txtFilas2.Name = "txtFilas2";
            this.txtFilas2.Size = new System.Drawing.Size(100, 22);
            this.txtFilas2.TabIndex = 2;
            // 
            // btnMatriz2
            // 
            this.btnMatriz2.Location = new System.Drawing.Point(61, 115);
            this.btnMatriz2.Name = "btnMatriz2";
            this.btnMatriz2.Size = new System.Drawing.Size(138, 41);
            this.btnMatriz2.TabIndex = 1;
            this.btnMatriz2.Text = "Crear Matriz #2";
            this.btnMatriz2.UseVisualStyleBackColor = true;
            this.btnMatriz2.Click += new System.EventHandler(this.btnMatriz2_Click);
            // 
            // Matriz_dgv_Simisterra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dgvMultiplicar);
            this.Controls.Add(this.dgvMatriz2);
            this.Controls.Add(this.dgvMatriz1);
            this.Controls.Add(this.btnMultiplicar);
            this.Controls.Add(this.Cols2);
            this.Controls.Add(this.Filas2);
            this.Controls.Add(this.Cols1);
            this.Controls.Add(this.Filas1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Name = "Matriz_dgv_Simisterra";
            this.Text = "Matriz_dgv_Simisterra";
            ((System.ComponentModel.ISupportInitialize)(this.dgvMultiplicar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMatriz2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMatriz1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvMultiplicar;
        private System.Windows.Forms.DataGridView dgvMatriz2;
        private System.Windows.Forms.DataGridView dgvMatriz1;
        private System.Windows.Forms.Button btnMultiplicar;
        private System.Windows.Forms.Label Cols2;
        private System.Windows.Forms.Label Filas2;
        private System.Windows.Forms.Label Cols1;
        private System.Windows.Forms.Label Filas1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtCols1;
        private System.Windows.Forms.TextBox txtFilas1;
        private System.Windows.Forms.Button btnMatriz1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtCols2;
        private System.Windows.Forms.TextBox txtFilas2;
        private System.Windows.Forms.Button btnMatriz2;
    }
}