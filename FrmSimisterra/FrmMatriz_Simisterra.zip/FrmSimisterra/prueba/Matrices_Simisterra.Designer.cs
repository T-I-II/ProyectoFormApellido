﻿namespace prueba
{
    partial class Matrices_Simisterra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMatriz1 = new System.Windows.Forms.Button();
            this.btnMatriz2 = new System.Windows.Forms.Button();
            this.Filas1 = new System.Windows.Forms.Label();
            this.Cols1 = new System.Windows.Forms.Label();
            this.Cols2 = new System.Windows.Forms.Label();
            this.Filas2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtCols1 = new System.Windows.Forms.TextBox();
            this.txtFilas1 = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtCols2 = new System.Windows.Forms.TextBox();
            this.txtFilas2 = new System.Windows.Forms.TextBox();
            this.btnMultiplicar = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnMatriz1
            // 
            this.btnMatriz1.Location = new System.Drawing.Point(52, 115);
            this.btnMatriz1.Name = "btnMatriz1";
            this.btnMatriz1.Size = new System.Drawing.Size(131, 41);
            this.btnMatriz1.TabIndex = 0;
            this.btnMatriz1.Text = "Crear matriz #1";
            this.btnMatriz1.UseVisualStyleBackColor = true;
            this.btnMatriz1.Click += new System.EventHandler(this.btnMatriz1_Click);
            // 
            // btnMatriz2
            // 
            this.btnMatriz2.Location = new System.Drawing.Point(61, 115);
            this.btnMatriz2.Name = "btnMatriz2";
            this.btnMatriz2.Size = new System.Drawing.Size(138, 41);
            this.btnMatriz2.TabIndex = 1;
            this.btnMatriz2.Text = "Crear Matriz #2";
            this.btnMatriz2.UseVisualStyleBackColor = true;
            this.btnMatriz2.Click += new System.EventHandler(this.btnMatriz2_Click);
            // 
            // Filas1
            // 
            this.Filas1.AutoSize = true;
            this.Filas1.Location = new System.Drawing.Point(155, 69);
            this.Filas1.Name = "Filas1";
            this.Filas1.Size = new System.Drawing.Size(36, 16);
            this.Filas1.TabIndex = 2;
            this.Filas1.Text = "Filas";
            // 
            // Cols1
            // 
            this.Cols1.AutoSize = true;
            this.Cols1.Location = new System.Drawing.Point(155, 113);
            this.Cols1.Name = "Cols1";
            this.Cols1.Size = new System.Drawing.Size(67, 16);
            this.Cols1.TabIndex = 3;
            this.Cols1.Text = "Columnas";
            // 
            // Cols2
            // 
            this.Cols2.AutoSize = true;
            this.Cols2.Location = new System.Drawing.Point(534, 104);
            this.Cols2.Name = "Cols2";
            this.Cols2.Size = new System.Drawing.Size(67, 16);
            this.Cols2.TabIndex = 5;
            this.Cols2.Text = "Columnas";
            // 
            // Filas2
            // 
            this.Filas2.AutoSize = true;
            this.Filas2.Location = new System.Drawing.Point(534, 60);
            this.Filas2.Name = "Filas2";
            this.Filas2.Size = new System.Drawing.Size(36, 16);
            this.Filas2.TabIndex = 4;
            this.Filas2.Text = "Filas";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtCols1);
            this.groupBox1.Controls.Add(this.txtFilas1);
            this.groupBox1.Controls.Add(this.btnMatriz1);
            this.groupBox1.Location = new System.Drawing.Point(141, 29);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(226, 167);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Matriz #1";
            // 
            // txtCols1
            // 
            this.txtCols1.Location = new System.Drawing.Point(83, 81);
            this.txtCols1.Name = "txtCols1";
            this.txtCols1.Size = new System.Drawing.Size(100, 22);
            this.txtCols1.TabIndex = 5;
            // 
            // txtFilas1
            // 
            this.txtFilas1.Location = new System.Drawing.Point(83, 37);
            this.txtFilas1.Name = "txtFilas1";
            this.txtFilas1.Size = new System.Drawing.Size(100, 22);
            this.txtFilas1.TabIndex = 4;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtCols2);
            this.groupBox2.Controls.Add(this.txtFilas2);
            this.groupBox2.Controls.Add(this.btnMatriz2);
            this.groupBox2.Location = new System.Drawing.Point(506, 29);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(239, 167);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Matriz #2";
            // 
            // txtCols2
            // 
            this.txtCols2.Location = new System.Drawing.Point(99, 72);
            this.txtCols2.Name = "txtCols2";
            this.txtCols2.Size = new System.Drawing.Size(100, 22);
            this.txtCols2.TabIndex = 3;
            // 
            // txtFilas2
            // 
            this.txtFilas2.Location = new System.Drawing.Point(99, 28);
            this.txtFilas2.Name = "txtFilas2";
            this.txtFilas2.Size = new System.Drawing.Size(100, 22);
            this.txtFilas2.TabIndex = 2;
            // 
            // btnMultiplicar
            // 
            this.btnMultiplicar.Location = new System.Drawing.Point(343, 202);
            this.btnMultiplicar.Name = "btnMultiplicar";
            this.btnMultiplicar.Size = new System.Drawing.Size(179, 43);
            this.btnMultiplicar.TabIndex = 8;
            this.btnMultiplicar.Text = "Multiplicar Matrices";
            this.btnMultiplicar.UseVisualStyleBackColor = true;
            this.btnMultiplicar.Click += new System.EventHandler(this.btnMultiplicar_Click);
            // 
            // Matrices_Simisterra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(885, 656);
            this.Controls.Add(this.btnMultiplicar);
            this.Controls.Add(this.Cols2);
            this.Controls.Add(this.Filas2);
            this.Controls.Add(this.Cols1);
            this.Controls.Add(this.Filas1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Matrices_Simisterra";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Matrices_Simisterra";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnMatriz1;
        private System.Windows.Forms.Button btnMatriz2;
        private System.Windows.Forms.Label Filas1;
        private System.Windows.Forms.Label Cols1;
        private System.Windows.Forms.Label Cols2;
        private System.Windows.Forms.Label Filas2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnMultiplicar;
        private System.Windows.Forms.TextBox txtCols1;
        private System.Windows.Forms.TextBox txtFilas1;
        private System.Windows.Forms.TextBox txtCols2;
        private System.Windows.Forms.TextBox txtFilas2;
    }
}